-- ============================================
-- 종합 실습 과제 2 — 도서관 대출 시스템 시드 스크립트
-- 사용법: psql -U postgres -d shop_db -f library_db_seed.sql
-- 주의: 스스로 설계한 테이블로 먼저 시도한 뒤,
--       막히면 이 파일의 CREATE TABLE 부분을 참고하세요.
-- ============================================

DROP TABLE IF EXISTS loans;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS members;
DROP TABLE IF EXISTS publishers;

CREATE TABLE publishers (
    publisher_id   SERIAL PRIMARY KEY,
    publisher_name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE books (
    book_id      SERIAL PRIMARY KEY,
    title        VARCHAR(100) NOT NULL,
    publisher_id INT REFERENCES publishers(publisher_id),
    price        NUMERIC(10,2) NOT NULL CHECK (price > 0),
    published_on DATE NOT NULL,
    copies       INT NOT NULL DEFAULT 1 CHECK (copies >= 0)
);

CREATE TABLE members (
    member_id   SERIAL PRIMARY KEY,
    member_name VARCHAR(50) NOT NULL,
    email       VARCHAR(100) NOT NULL UNIQUE,
    join_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    membership  VARCHAR(10) NOT NULL DEFAULT '일반'
                CHECK (membership IN ('일반','우수','정지'))
);

CREATE TABLE loans (
    loan_id     SERIAL PRIMARY KEY,
    book_id     INT NOT NULL REFERENCES books(book_id),
    member_id   INT NOT NULL REFERENCES members(member_id),
    loan_date   DATE NOT NULL,
    due_date    DATE NOT NULL,
    return_date DATE,
    CONSTRAINT chk_due CHECK (due_date >= loan_date)
);

INSERT INTO publishers (publisher_name) VALUES
('한빛출판'), ('길벗미디어'), ('인사이트'), ('제이펍');

INSERT INTO books (title, publisher_id, price, published_on, copies) VALUES
('SQL 첫걸음',        1, 22000, '2023-03-10', 3),
('데이터베이스 개론', 2, 27000, '2022-09-01', 2),
('파이썬 입문',       1, 25000, '2024-01-15', 4),
('클린 코드',         3, 33000, '2021-05-20', 2),
('알고리즘 도감',     4, 19000, '2023-11-05', 1),
('네트워크 기초',     2, 28000, '2020-07-30', 2),
('리팩터링',          3, 38000, '2024-06-01', 1);

INSERT INTO members (member_name, email, join_date, membership) VALUES
('김서준', 'seojun@lib.com',  '2024-02-01', '우수'),
('이하윤', 'hayoon@lib.com',  '2024-05-12', '일반'),
('박지호', 'jiho@lib.com',    '2025-01-08', '일반'),
('최유나', 'yuna@lib.com',    '2025-03-22', '일반'),
('정민재', 'minjae@lib.com',  '2025-06-30', '정지');

INSERT INTO loans (book_id, member_id, loan_date, due_date, return_date) VALUES
(1, 1, '2025-06-01', '2025-06-15', '2025-06-12'),
(2, 1, '2025-06-01', '2025-06-15', '2025-06-20'),
(1, 2, '2025-06-05', '2025-06-19', '2025-06-18'),
(3, 3, '2025-06-10', '2025-06-24', NULL),
(4, 1, '2025-06-20', '2025-07-04', '2025-07-01'),
(1, 4, '2025-06-25', '2025-07-09', NULL),
(5, 2, '2025-07-01', '2025-07-15', '2025-07-30'),
(3, 1, '2025-07-05', '2025-07-19', '2025-07-19'),
(6, 3, '2025-07-10', '2025-07-24', NULL);
