# 종합 실습 과제

## 이 과제에 대하여

교재 전체에서 배운 내용을 하나로 엮는 실습입니다. 두 개의 과제로 구성됩니다.

| 과제 | 내용 | 관련 장 | 예상 소요 |
|---|---|---|---|
| **과제 1** | `shop_db` 매출 분석 리포트 작성 | 4~10장 | 2~3시간 |
| **과제 2** | 도서관 대출 시스템 설계와 구축 | 11~13장 + 4~10장 | 3~4시간 |

과제 1은 **읽는 능력**을, 과제 2는 **만드는 능력**을 확인합니다. 순서대로 진행하는 것을 권장합니다.

> **풀이 방법**: 문제를 보고 바로 정답을 확인하지 마세요. 먼저 스스로 작성해 실행해 보고, 결과가 예시와 다르면 어디가 다른지 비교하며 원인을 찾는 과정에서 가장 많이 배웁니다. 막히면 "관련 장" 표시를 참고해 해당 장을 다시 보세요.

---

# 과제 1. shop_db 매출 분석 리포트

## 상황

여러분은 이 쇼핑몰의 데이터 분석 담당자입니다. 팀장이 상반기 실적 리포트에 넣을 수치를 요청했습니다. 아래 14개 질문에 답하는 SQL을 작성하세요.

## 공통 규칙

- **취소된 주문은 매출에서 제외**합니다 (`status <> '취소'`)
- 주문 금액은 `order_items`의 `quantity * unit_price` 합계입니다
- 금액에 소수점이 나오면 그대로 두거나 `ROUND`로 정리해도 됩니다
- 결과의 정렬 순서까지 예시와 맞춰 보세요

---

### 문제 1. 카테고리별 매출액 *(7장, 6장)*

카테고리 이름별 매출액을 많은 순으로 조회하세요.

**예상 결과**

| category_name | 매출액 |
|---|---|
| 전자제품 | 223000.00 |
| 생활용품 | 56000.00 |
| 식품 | 54000.00 |
| 도서 | 49000.00 |

> 의류가 결과에 없는 이유를 설명할 수 있어야 합니다.

---

### 문제 2. 고객별 구매액 순위 *(9장, 10장)*

고객별 총 구매액을 구하고 순위를 매기세요.

**예상 결과**

| 순위 | customer_name | 총구매액 |
|---|---|---|
| 1 | 김민준 | 158000.00 |
| 2 | 정하은 | 121000.00 |
| 3 | 박도윤 | 54000.00 |
| 4 | 이서연 | 49000.00 |

---

### 문제 3. 월별 매출과 누적 매출 *(5장, 6장, 10장)*

월별 매출액과 함께 누적 매출을 조회하세요.

**예상 결과**

| 월 | 매출 | 누적매출 |
|---|---|---|
| 2025-06-01 | 261000.00 | 261000.00 |
| 2025-07-01 | 121000.00 | 382000.00 |

---

### 문제 4. 판매 실적이 없는 상품과 묶인 재고 *(9장)*

한 번도 판매되지 않은 상품과 그 상품에 묶여 있는 재고 금액을 조회하세요.

**예상 결과**

| product_id | product_name | 재고금액 |
|---|---|---|
| 6 | 견과류 세트 | 0.00 |
| 10 | 후드 집업 | 336000.00 |

---

### 문제 5. 평가가 좋은 상품 *(6장, 7장)*

평균 별점이 4점 이상인 상품을 리뷰 수와 함께 조회하세요.

**예상 결과**

| product_name | 평균별점 | 리뷰수 |
|---|---|---|
| SQL 첫걸음 | 5.0 | 1 |
| 무선 이어폰 | 4.5 | 2 |

---

### 문제 6. 고객 활동 기간 *(6장, 7장)*

고객별 첫 주문일, 최근 주문일, 그 사이 기간(일), 주문 횟수를 조회하세요.

**예상 결과**

| customer_name | 첫주문 | 최근주문 | 기간일수 | 주문수 |
|---|---|---|---|---|
| 김민준 | 2025-06-01 | 2025-06-10 | 9 | 2 |
| 이서연 | 2025-06-03 | 2025-06-03 | 0 | 1 |
| 박도윤 | 2025-06-12 | 2025-06-12 | 0 | 1 |
| ... 외 2건 | | | | |

---

### 문제 7. 카테고리별 대표 상품 *(10장, 9장)*

카테고리마다 가장 비싼 상품을 하나씩 조회하세요.

**예상 결과**

| category_name | product_name | price |
|---|---|---|
| 전자제품 | 무선 이어폰 | 89000.00 |
| 의류 | 후드 집업 | 42000.00 |
| 생활용품 | 스탠드 조명 | 32000.00 |
| 도서 | 데이터베이스 개론 | 27000.00 |
| 식품 | 견과류 세트 | 25000.00 |

---

### 문제 8. 담당자별 실적 *(7장, 5장)*

담당 직원별 주문 건수와 매출액을 조회하세요. **담당자가 배정되지 않은 주문도** "(미배정)"**으로 표시**되어야 합니다.

**예상 결과**

| 담당자 | 주문수 | 매출액 |
|---|---|---|
| 오유진 | 3 | 283000.00 |
| (미배정) | 1 | 54000.00 |
| 한지민 | 1 | 45000.00 |

---

### 문제 9. 상품별 재고와 판매량 *(7장, 6장)*

모든 상품의 재고와 총 판매 수량을 조회하세요. 팔린 적 없는 상품은 0으로 표시합니다.

**예상 결과** (상위 5건)

| product_name | 재고 | 판매수량 |
|---|---|---|
| 원두커피 1kg | 60 | 3 |
| 무선 이어폰 | 45 | 2 |
| 머그컵 | 100 | 2 |
| 면 티셔츠 | 50 | 2 |
| 블루투스 키보드 | 20 | 1 |

---

### 문제 10. 평균 이상 주문 *(9장)*

주문 한 건당 평균 금액보다 큰 주문을 고객 이름과 함께 조회하세요.

**예상 결과**

| order_id | customer_name | 금액 | 평균 |
|---|---|---|---|
| 6 | 정하은 | 121000.00 | 70000 |
| 1 | 김민준 | 113000.00 | 70000 |

---

### 문제 11. 고객 등급 부여 *(5장, 7장, 9장)*

구매액에 따라 고객 등급을 부여하세요. 15만 원 이상은 GOLD, 5만 원 이상은 SILVER, 나머지는 BRONZE입니다. **구매 실적이 없는 고객도 표시**되어야 합니다.

**예상 결과**

| customer_name | 총구매액 | 등급 |
|---|---|---|
| 김민준 | 158000.00 | GOLD |
| 정하은 | 121000.00 | SILVER |
| 박도윤 | 54000.00 | SILVER |
| 이서연 | 49000.00 | BRONZE |
| 최지우 | 0 | BRONZE |

> 최지우 고객이 0원인 이유를 확인하세요. 이 고객은 주문을 하긴 했습니다.

---

### 문제 12. 카테고리별 매출 비중 *(10장)*

카테고리별 매출과 전체 대비 비중, 누적 매출을 조회하세요.

**예상 결과**

| category_name | 매출 | 비중 | 누적매출 |
|---|---|---|---|
| 전자제품 | 223000.00 | 58.4 | 223000.00 |
| 생활용품 | 56000.00 | 14.7 | 279000.00 |
| 식품 | 54000.00 | 14.1 | 333000.00 |
| 도서 | 49000.00 | 12.8 | 382000.00 |

---

### 문제 13. 재구매 고객 *(6장, 7장)*

두 번 이상 주문한 고객을 찾으세요.

---

### 문제 14. 같은 문제, 세 가지 방법 *(7장, 8장, 9장)*

리뷰가 하나도 달리지 않은 상품을 **세 가지 방법**으로 각각 작성하세요.

1. `LEFT JOIN` + `IS NULL`
2. `EXCEPT`
3. `NOT EXISTS`

세 결과가 모두 같은지 확인하고, 각 방법의 장단점을 정리하세요.

---

# 과제 2. 도서관 대출 시스템

## 상황

작은 도서관의 대출 관리 시스템을 만들어 달라는 요청을 받았습니다. 요구사항은 다음과 같습니다.

- 도서는 제목, 출판사, 정가, 출간일, 보유 권수를 관리한다
- 회원은 이름, 이메일, 가입일, 회원 등급(일반 / 우수 / 정지)을 가진다
- 대출 기록은 어떤 도서를 누가 언제 빌렸고, 반납 예정일과 실제 반납일이 언제인지 기록한다
- 아직 반납하지 않은 도서는 반납일이 비어 있다
- 출판사는 별도 테이블로 관리한다

## 2단계로 진행합니다

- **2-A: 설계와 구축** — 테이블을 직접 만들고 데이터를 넣습니다
- **2-B: 운영 쿼리 작성** — 만든 데이터베이스에 질문을 던집니다

---

## 과제 2-A. 설계와 구축 *(11장, 12장)*

### A-1. 테이블 설계

다음 조건을 만족하는 네 개의 테이블을 만드세요.

**publishers** (출판사)
- 출판사 번호: 자동 증가, 기본키
- 출판사명: 50자, 필수, 중복 불가

**books** (도서)
- 도서 번호: 자동 증가, 기본키
- 제목: 100자, 필수
- 출판사 번호: `publishers` 참조
- 정가: 금액을 정확히 저장, 필수, 0보다 커야 함
- 출간일: 필수
- 보유 권수: 필수, 기본값 1, 0 이상

**members** (회원)
- 회원 번호: 자동 증가, 기본키
- 이름: 50자, 필수
- 이메일: 100자, 필수, 중복 불가
- 가입일: 필수, 기본값은 오늘
- 등급: 10자, 필수, 기본값 '일반', **'일반' / '우수' / '정지' 중 하나만** 허용

**loans** (대출)
- 대출 번호: 자동 증가, 기본키
- 도서 번호: 필수, `books` 참조
- 회원 번호: 필수, `members` 참조
- 대출일: 필수
- 반납예정일: 필수, **대출일보다 빠를 수 없음**
- 실제반납일: 비어 있을 수 있음 (아직 반납 안 함)

> **힌트**: 제약조건에 이름을 붙여 두면 나중에 오류 메시지를 읽기 편합니다. 테이블 생성 순서도 생각해 보세요 — 참조되는 테이블이 먼저 있어야 합니다.

### A-2. 제약조건 검증

만든 제약조건이 실제로 동작하는지 아래를 시도해 보고, 각각 어떤 오류가 나는지 기록하세요.

1. 정가를 0으로 입력
2. 등급을 'VIP'로 입력
3. 반납예정일을 대출일보다 이른 날짜로 입력
4. 존재하지 않는 회원 번호로 대출 기록 입력
5. 대출 기록이 있는 회원을 삭제

### A-3. 데이터 입력

교재와 함께 제공되는 `library_db_seed.sql`을 실행하면 아래 데이터가 들어갑니다. 직접 만든 스키마가 이 데이터를 받아들이는지 확인하세요.

- 출판사 4곳, 도서 7종, 회원 5명, 대출 기록 9건

데이터가 들어간 뒤 아래를 확인합니다.

```sql
SELECT COUNT(*) FROM publishers;  -- 4
SELECT COUNT(*) FROM books;       -- 7
SELECT COUNT(*) FROM members;     -- 5
SELECT COUNT(*) FROM loans;       -- 9
```

### A-4. 반납 처리

4번 대출 건을 2025년 8월 1일에 반납 처리하세요. **트랜잭션으로 묶고, 결과를 확인한 뒤 커밋**합니다. `RETURNING`으로 처리 결과를 확인하세요.

---

## 과제 2-B. 운영 쿼리 작성 *(4~10장, 13장)*

### B-1. 현재 대출 중인 도서

아직 반납되지 않은 도서를 반납예정일이 빠른 순으로 조회하세요. 도서 제목, 대출한 회원 이름, 대출일, 반납예정일을 표시합니다.

**예상 결과**

| title | member_name | loan_date | due_date |
|---|---|---|---|
| 파이썬 입문 | 박지호 | 2025-06-10 | 2025-06-24 |
| SQL 첫걸음 | 최유나 | 2025-06-25 | 2025-07-09 |
| 네트워크 기초 | 박지호 | 2025-07-10 | 2025-07-24 |

### B-2. 연체 반납 이력

반납예정일을 넘겨 반납한 기록을 연체일수가 많은 순으로 조회하세요.

**예상 결과**

| title | member_name | due_date | return_date | 연체일수 |
|---|---|---|---|---|
| 알고리즘 도감 | 이하윤 | 2025-07-15 | 2025-07-30 | 15 |
| 데이터베이스 개론 | 김서준 | 2025-06-15 | 2025-06-20 | 5 |

### B-3. 회원별 대출 횟수

회원별 대출 횟수를 조회하세요. **한 번도 빌리지 않은 회원도 0으로 표시**되어야 합니다.

**예상 결과**

| member_name | membership | 대출횟수 |
|---|---|---|
| 김서준 | 우수 | 4 |
| 이하윤 | 일반 | 2 |
| 박지호 | 일반 | 2 |
| 최유나 | 일반 | 1 |
| 정민재 | 정지 | 0 |

### B-4. 인기 도서 순위

대출 횟수가 많은 순으로 도서 순위를 매기세요. 동점은 같은 순위로 처리합니다.

**예상 결과**

| 순위 | title | 대출횟수 |
|---|---|---|
| 1 | SQL 첫걸음 | 3 |
| 2 | 파이썬 입문 | 2 |
| 3 | 데이터베이스 개론 | 1 |
| 3 | 클린 코드 | 1 |
| ... 외 2건 | | |

### B-5. 한 번도 대출되지 않은 도서

**예상 결과**

| book_id | title |
|---|---|
| 7 | 리팩터링 |

### B-6. 출판사별 통계

출판사별 보유 도서 종수, 평균 정가, 총 보유 권수를 조회하세요.

**예상 결과**

| publisher_name | 도서수 | 평균가 | 총권수 |
|---|---|---|---|
| 한빛출판 | 2 | 23500 | 7 |
| 길벗미디어 | 2 | 27500 | 4 |
| 인사이트 | 2 | 35500 | 3 |
| 제이펍 | 1 | 19000 | 1 |

### B-7. 회원별 연체 이력

회원별 연체 횟수를 구하고, 연체가 있으면 '주의', 없으면 '양호'로 판정하세요. 연체 이력이 없는 회원도 0으로 표시합니다.

**예상 결과**

| member_name | 연체횟수 | 판정 |
|---|---|---|
| 김서준 | 1 | 주의 |
| 이하윤 | 1 | 주의 |
| 박지호 | 0 | 양호 |
| 최유나 | 0 | 양호 |
| 정민재 | 0 | 양호 |

### B-8. 월별 대출 추이

월별 대출 건수와 누적 건수를 조회하세요.

**예상 결과**

| 월 | 대출건수 | 누적 |
|---|---|---|
| 2025-06-01 | 6 | 6 |
| 2025-07-01 | 3 | 9 |

### B-9. 회원의 대출 간격

각 대출 건마다 그 회원의 직전 대출일과 간격(일)을 함께 조회하세요.

### B-10. 대출 현황 View

대출 상태를 한눈에 보여주는 `v_loan_status` View를 만드세요. 기준일은 2025년 8월 1일로 합니다.

| 상태 | 조건 |
|---|---|
| 대출중 | 미반납이고 반납예정일이 아직 지나지 않음 |
| 연체중 | 미반납이고 반납예정일이 지남 |
| 정상반납 | 예정일 안에 반납 |
| 연체반납 | 예정일을 넘겨 반납 |

View를 만든 뒤 상태별 건수를 집계하세요.

**예상 결과**

| 상태 | 건수 |
|---|---|
| 정상반납 | 4 |
| 연체중 | 3 |
| 연체반납 | 2 |

---

# 정답 및 해설

> 반드시 스스로 작성해 본 뒤 확인하세요.

## 과제 1 정답

**문제 1**
```sql
SELECT c.category_name, SUM(oi.quantity * oi.unit_price) AS 매출액
FROM order_items oi
JOIN orders     o ON oi.order_id   = o.order_id
JOIN products   p ON oi.product_id = p.product_id
JOIN categories c ON p.category_id = c.category_id
WHERE o.status <> '취소'
GROUP BY c.category_id, c.category_name
ORDER BY 매출액 DESC;
```

**의류가 없는 이유**: 의류 상품(면 티셔츠)이 팔린 유일한 주문이 5번인데, 이 주문은 취소되었기 때문입니다. `WHERE`에서 걸러지면서 의류 그룹 자체가 사라졌습니다. 6장 예제 6-15에서 다룬 것과 같은 상황입니다.

**문제 2**
```sql
WITH 고객매출 AS (
    SELECT c.customer_id, c.customer_name,
           SUM(oi.quantity * oi.unit_price) AS 총구매액
    FROM customers c
    JOIN orders      o  ON c.customer_id = o.customer_id
    JOIN order_items oi ON o.order_id    = oi.order_id
    WHERE o.status <> '취소'
    GROUP BY c.customer_id, c.customer_name
)
SELECT RANK() OVER (ORDER BY 총구매액 DESC) AS 순위, customer_name, 총구매액
FROM 고객매출
ORDER BY 순위;
```
집계와 윈도우 함수를 한 쿼리에서 동시에 쓸 수 없으므로 CTE로 나눕니다.

**문제 3**
```sql
WITH 월매출 AS (
    SELECT DATE_TRUNC('month', o.order_date)::DATE AS 월,
           SUM(oi.quantity * oi.unit_price)        AS 매출
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    WHERE o.status <> '취소'
    GROUP BY DATE_TRUNC('month', o.order_date)
)
SELECT 월, 매출, SUM(매출) OVER (ORDER BY 월) AS 누적매출
FROM 월매출
ORDER BY 월;
```

**문제 4**
```sql
SELECT p.product_id, p.product_name, p.price * p.stock_quantity AS 재고금액
FROM products p
WHERE NOT EXISTS (
    SELECT 1 FROM order_items oi WHERE oi.product_id = p.product_id
)
ORDER BY p.product_id;
```
견과류 세트는 재고 자체가 0이라 재고금액도 0입니다. 후드 집업은 336,000원이 묶여 있으므로 판매 촉진이 필요한 상품으로 볼 수 있습니다.

**문제 5**
```sql
SELECT p.product_name, ROUND(AVG(r.rating), 1) AS 평균별점, COUNT(*) AS 리뷰수
FROM reviews r
JOIN products p ON r.product_id = p.product_id
GROUP BY p.product_id, p.product_name
HAVING AVG(r.rating) >= 4
ORDER BY 평균별점 DESC, p.product_id;
```
`HAVING`에는 별칭을 쓸 수 없으므로 `AVG(r.rating)`을 그대로 반복합니다.

**문제 6**
```sql
SELECT c.customer_name,
       MIN(o.order_date)                     AS 첫주문,
       MAX(o.order_date)                     AS 최근주문,
       MAX(o.order_date) - MIN(o.order_date) AS 기간일수,
       COUNT(*)                              AS 주문수
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.customer_name
ORDER BY c.customer_id;
```
`MIN`과 `MAX`는 날짜에도 쓸 수 있고, 날짜끼리 빼면 일수가 나옵니다.

**문제 7**
```sql
WITH 순위 AS (
    SELECT c.category_name, p.product_name, p.price,
           ROW_NUMBER() OVER (PARTITION BY p.category_id ORDER BY p.price DESC) AS rn
    FROM products p
    JOIN categories c ON p.category_id = c.category_id
)
SELECT category_name, product_name, price
FROM 순위
WHERE rn = 1
ORDER BY price DESC;
```
10장의 "그룹별 상위 N건" 패턴입니다. 윈도우 함수는 `WHERE`에서 쓸 수 없어 CTE가 필수입니다.

**문제 8**
```sql
SELECT COALESCE(e.employee_name, '(미배정)') AS 담당자,
       COUNT(DISTINCT o.order_id)            AS 주문수,
       SUM(oi.quantity * oi.unit_price)      AS 매출액
FROM orders o
LEFT JOIN employees e ON o.employee_id = e.employee_id
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.status <> '취소'
GROUP BY e.employee_id, e.employee_name
ORDER BY 매출액 DESC;
```
두 가지가 핵심입니다. `LEFT JOIN`을 써야 담당자 없는 4번 주문이 남고, `COUNT(*)`가 아니라 `COUNT(DISTINCT o.order_id)`를 써야 합니다. `order_items`를 조인하면서 한 주문이 여러 행으로 늘어났기 때문입니다.

**문제 9**
```sql
SELECT p.product_name, p.stock_quantity AS 재고,
       COALESCE(SUM(oi.quantity), 0)    AS 판매수량
FROM products p
LEFT JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY p.product_id, p.product_name, p.stock_quantity
ORDER BY 판매수량 DESC, p.product_id;
```
`SUM`은 대상 행이 없으면 0이 아니라 **NULL**을 반환합니다. `COALESCE`로 0을 채워야 합니다. `COUNT`가 0을 돌려주는 것과 다르니 주의하세요.

**문제 10**
```sql
WITH 주문금액 AS (
    SELECT order_id, SUM(quantity * unit_price) AS 금액
    FROM order_items GROUP BY order_id
)
SELECT a.order_id, c.customer_name, a.금액,
       ROUND((SELECT AVG(금액) FROM 주문금액)) AS 평균
FROM 주문금액 a
JOIN orders    o ON a.order_id    = o.order_id
JOIN customers c ON o.customer_id = c.customer_id
WHERE a.금액 > (SELECT AVG(금액) FROM 주문금액)
ORDER BY a.금액 DESC;
```
같은 CTE를 본문과 서브쿼리에서 두 번 참조합니다. 인라인 뷰로 작성하면 같은 쿼리를 두 번 써야 합니다.

**문제 11**
```sql
WITH 고객매출 AS (
    SELECT c.customer_id, c.customer_name,
           COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS 총구매액
    FROM customers c
    LEFT JOIN orders o ON c.customer_id = o.customer_id AND o.status <> '취소'
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    GROUP BY c.customer_id, c.customer_name
)
SELECT customer_name, 총구매액,
       CASE WHEN 총구매액 >= 150000 THEN 'GOLD'
            WHEN 총구매액 >= 50000  THEN 'SILVER'
            ELSE 'BRONZE'
       END AS 등급
FROM 고객매출
ORDER BY 총구매액 DESC;
```

**이 문제의 핵심은 취소 조건의 위치입니다.** `o.status <> '취소'`를 `WHERE`에 두면 주문이 취소뿐인 최지우 고객이 통째로 사라집니다. `LEFT JOIN`의 `ON` 절에 두어야 고객은 남고 금액만 비게 됩니다. 7장에서 다룬 "`ON` 조건과 `WHERE` 조건의 차이"가 실제 리포트에서 결과를 가르는 순간입니다.

**문제 12**
```sql
WITH 카테고리매출 AS (
    SELECT c.category_id, c.category_name,
           SUM(oi.quantity * oi.unit_price) AS 매출
    FROM order_items oi
    JOIN orders     o ON oi.order_id   = o.order_id
    JOIN products   p ON oi.product_id = p.product_id
    JOIN categories c ON p.category_id = c.category_id
    WHERE o.status <> '취소'
    GROUP BY c.category_id, c.category_name
)
SELECT category_name, 매출,
       ROUND(매출 * 100.0 / SUM(매출) OVER (), 1)  AS 비중,
       SUM(매출) OVER (ORDER BY 매출 DESC)         AS 누적매출
FROM 카테고리매출
ORDER BY 매출 DESC;
```
`OVER ()`는 전체 합계를, `OVER (ORDER BY 매출 DESC)`는 누적 합계를 만듭니다. 같은 `SUM`이라도 `OVER` 안의 내용에 따라 의미가 완전히 달라집니다.

**문제 13**
```sql
SELECT c.customer_name, COUNT(*) AS 주문수
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.customer_name
HAVING COUNT(*) >= 2;
```
김민준 고객 1명입니다.

**문제 14**
```sql
-- 1. LEFT JOIN + IS NULL
SELECT p.product_id FROM products p
LEFT JOIN reviews r ON p.product_id = r.product_id
WHERE r.review_id IS NULL ORDER BY p.product_id;

-- 2. EXCEPT
SELECT product_id FROM products
EXCEPT
SELECT product_id FROM reviews ORDER BY product_id;

-- 3. NOT EXISTS
SELECT p.product_id FROM products p
WHERE NOT EXISTS (SELECT 1 FROM reviews r WHERE r.product_id = p.product_id)
ORDER BY p.product_id;
```

세 방법 모두 2, 3, 5, 6, 8, 10번 상품을 반환합니다.

| 방법 | 장점 | 단점 |
|---|---|---|
| `LEFT JOIN` + `IS NULL` | 상대 테이블의 컬럼도 함께 조회 가능 | 의도가 덜 드러남. 1:N이면 중복 주의 |
| `EXCEPT` | 가장 짧고 의도가 명확 | 비교 컬럼만 얻을 수 있음 |
| `NOT EXISTS` | 의도가 명확하고 NULL에 안전 | 다른 컬럼이 필요하면 조인 추가 필요 |

`NOT IN`은 서브쿼리에 NULL이 있으면 결과가 통째로 비므로 이 자리에서는 피하는 것이 좋습니다.

---

## 과제 2 정답

### A-1. 테이블 생성

```sql
CREATE TABLE publishers (
    publisher_id   SERIAL PRIMARY KEY,
    publisher_name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE books (
    book_id      SERIAL PRIMARY KEY,
    title        VARCHAR(100) NOT NULL,
    publisher_id INT REFERENCES publishers(publisher_id),
    price        NUMERIC(10,2) NOT NULL CHECK (price > 0),
    published_on DATE NOT NULL,
    copies       INT NOT NULL DEFAULT 1 CHECK (copies >= 0)
);

CREATE TABLE members (
    member_id   SERIAL PRIMARY KEY,
    member_name VARCHAR(50) NOT NULL,
    email       VARCHAR(100) NOT NULL UNIQUE,
    join_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    membership  VARCHAR(10) NOT NULL DEFAULT '일반'
                CHECK (membership IN ('일반','우수','정지'))
);

CREATE TABLE loans (
    loan_id     SERIAL PRIMARY KEY,
    book_id     INT NOT NULL REFERENCES books(book_id),
    member_id   INT NOT NULL REFERENCES members(member_id),
    loan_date   DATE NOT NULL,
    due_date    DATE NOT NULL,
    return_date DATE,
    CONSTRAINT chk_due CHECK (due_date >= loan_date)
);
```

**생성 순서가 중요합니다.** `books`가 `publishers`를 참조하므로 `publishers`가 먼저 있어야 하고, `loans`는 `books`와 `members`를 모두 참조하므로 마지막입니다.

`chk_due`는 두 컬럼을 함께 비교하므로 컬럼 뒤에 붙일 수 없고 **테이블 레벨**로 선언해야 합니다.

`return_date`에 `NOT NULL`을 붙이지 않은 것이 설계의 핵심입니다. NULL이 "아직 반납하지 않음"을 의미합니다.

### A-2. 제약조건 검증 결과

| 시도 | 오류 |
|---|---|
| 정가 0 | `violates check constraint "books_price_check"` |
| 등급 'VIP' | `violates check constraint "members_membership_check"` |
| 반납예정일 < 대출일 | `violates check constraint "chk_due"` |
| 없는 회원 번호 | `violates foreign key constraint "loans_member_id_fkey"` |
| 대출 있는 회원 삭제 | `update or delete on table "members" violates foreign key constraint "loans_member_id_fkey" on table "loans"` |

마지막 오류는 다음과 같이 나옵니다.

```
ERROR:  update or delete on table "members" violates foreign key constraint
        "loans_member_id_fkey" on table "loans"
DETAIL:  Key (member_id)=(1) is still referenced from table "loans".
```

회원을 지우려면 대출 기록을 먼저 지워야 합니다. 12장에서 배운 "삭제는 자식부터" 원칙입니다.

### A-4. 반납 처리

```sql
BEGIN;
UPDATE loans
SET return_date = DATE '2025-08-01'
WHERE loan_id = 4
RETURNING loan_id, book_id, return_date;
COMMIT;
```

`RETURNING`으로 처리 결과를 눈으로 확인한 뒤 `COMMIT`하는 것이 안전한 습관입니다. 결과가 이상하면 `ROLLBACK`하면 됩니다.

### B-1. 현재 대출 중인 도서

```sql
SELECT b.title, m.member_name, l.loan_date, l.due_date
FROM loans l
JOIN books   b ON l.book_id   = b.book_id
JOIN members m ON l.member_id = m.member_id
WHERE l.return_date IS NULL
ORDER BY l.due_date;
```
`= NULL`이 아니라 `IS NULL`입니다.

### B-2. 연체 반납 이력

```sql
SELECT b.title, m.member_name, l.due_date, l.return_date,
       l.return_date - l.due_date AS 연체일수
FROM loans l
JOIN books   b ON l.book_id   = b.book_id
JOIN members m ON l.member_id = m.member_id
WHERE l.return_date > l.due_date
ORDER BY 연체일수 DESC;
```
미반납 건은 `return_date`가 NULL이라 비교가 "알 수 없음"이 되어 자동으로 제외됩니다.

### B-3. 회원별 대출 횟수

```sql
SELECT m.member_name, m.membership, COUNT(l.loan_id) AS 대출횟수
FROM members m
LEFT JOIN loans l ON m.member_id = l.member_id
GROUP BY m.member_id, m.member_name, m.membership
ORDER BY 대출횟수 DESC, m.member_id;
```
`COUNT(*)`를 쓰면 정민재 회원이 0이 아니라 1로 나옵니다. `LEFT JOIN` 결과에 NULL로 채워진 행이 하나 존재하기 때문입니다.

### B-4. 인기 도서 순위

```sql
SELECT RANK() OVER (ORDER BY COUNT(*) DESC) AS 순위,
       b.title, COUNT(*) AS 대출횟수
FROM loans l
JOIN books b ON l.book_id = b.book_id
GROUP BY b.book_id, b.title
ORDER BY 순위, b.book_id;
```
윈도우 함수 안에 집계함수를 넣을 수 있습니다. `GROUP BY`로 묶인 뒤 그 결과에 순위가 매겨집니다.

### B-5. 한 번도 대출되지 않은 도서

```sql
SELECT b.book_id, b.title
FROM books b
WHERE NOT EXISTS (SELECT 1 FROM loans l WHERE l.book_id = b.book_id)
ORDER BY b.book_id;
```

### B-6. 출판사별 통계

```sql
SELECT p.publisher_name,
       COUNT(*)            AS 도서수,
       ROUND(AVG(b.price)) AS 평균가,
       SUM(b.copies)       AS 총권수
FROM books b
JOIN publishers p ON b.publisher_id = p.publisher_id
GROUP BY p.publisher_id, p.publisher_name
ORDER BY 도서수 DESC, p.publisher_id;
```
"도서 종수"와 "총 보유 권수"는 다릅니다. 전자는 `COUNT(*)`, 후자는 `SUM(copies)`입니다.

### B-7. 회원별 연체 이력

```sql
WITH 연체 AS (
    SELECT member_id, COUNT(*) AS 연체횟수
    FROM loans
    WHERE return_date > due_date
    GROUP BY member_id
)
SELECT m.member_name,
       COALESCE(y.연체횟수, 0) AS 연체횟수,
       CASE WHEN COALESCE(y.연체횟수, 0) = 0 THEN '양호' ELSE '주의' END AS 판정
FROM members m
LEFT JOIN 연체 y ON m.member_id = y.member_id
ORDER BY m.member_id;
```
연체가 있는 회원만 담은 CTE를 만들고 전체 회원에 `LEFT JOIN`하는 구조입니다. 연체 조건을 메인 쿼리의 `WHERE`에 두면 연체 없는 회원이 사라집니다.

### B-8. 월별 대출 추이

```sql
WITH 월별 AS (
    SELECT DATE_TRUNC('month', loan_date)::DATE AS 월, COUNT(*) AS 대출건수
    FROM loans
    GROUP BY DATE_TRUNC('month', loan_date)
)
SELECT 월, 대출건수, SUM(대출건수) OVER (ORDER BY 월) AS 누적
FROM 월별
ORDER BY 월;
```

### B-9. 회원의 대출 간격

```sql
SELECT m.member_name, l.loan_date,
       LAG(l.loan_date) OVER (PARTITION BY l.member_id ORDER BY l.loan_date) AS 직전대출일,
       l.loan_date - LAG(l.loan_date) OVER (PARTITION BY l.member_id ORDER BY l.loan_date) AS 간격
FROM loans l
JOIN members m ON l.member_id = m.member_id
ORDER BY m.member_id, l.loan_date;
```
`PARTITION BY`가 없으면 다른 회원의 대출일을 끌어오게 됩니다. 각 회원의 첫 대출은 비교 대상이 없어 NULL입니다.

### B-10. 대출 현황 View

```sql
CREATE VIEW v_loan_status AS
SELECT l.loan_id, b.title, p.publisher_name, m.member_name,
       l.loan_date, l.due_date, l.return_date,
       CASE WHEN l.return_date IS NULL AND l.due_date < DATE '2025-08-01' THEN '연체중'
            WHEN l.return_date IS NULL                                    THEN '대출중'
            WHEN l.return_date > l.due_date                               THEN '연체반납'
            ELSE '정상반납'
       END AS 상태
FROM loans l
JOIN books   b ON l.book_id   = b.book_id
JOIN members m ON l.member_id = m.member_id
LEFT JOIN publishers p ON b.publisher_id = p.publisher_id;

SELECT 상태, COUNT(*) AS 건수
FROM v_loan_status
GROUP BY 상태
ORDER BY 건수 DESC, 상태;
```

**`CASE`의 조건 순서가 중요합니다.** "미반납이고 기한 초과"를 먼저 판정해야 합니다. `WHEN l.return_date IS NULL THEN '대출중'`을 앞에 두면 연체중인 건까지 모두 '대출중'으로 분류됩니다.

`publishers`를 `LEFT JOIN`으로 연결한 이유는, `books.publisher_id`가 NULL을 허용하므로 출판사 정보가 없는 도서도 View에서 빠지지 않게 하기 위해서입니다.

---

## 마무리 점검

두 과제를 마쳤다면 아래를 스스로 확인해 보세요.

- [ ] `WHERE`와 `HAVING`, `ON`을 각각 언제 쓰는지 설명할 수 있다
- [ ] `LEFT JOIN`에서 조건을 `ON`과 `WHERE` 중 어디에 둘지 판단할 수 있다
- [ ] `COUNT(*)`와 `COUNT(컬럼)`을 상황에 맞게 고를 수 있다
- [ ] 집계 결과에 다시 조건을 걸어야 할 때 CTE를 떠올릴 수 있다
- [ ] 윈도우 함수 결과로 필터링하려면 한 단계 감싸야 한다는 것을 안다
- [ ] 요구사항을 읽고 적절한 데이터 타입과 제약조건을 선택할 수 있다
- [ ] 외래키가 있을 때 테이블 생성·입력·삭제 순서를 판단할 수 있다
- [ ] 위험한 `UPDATE`나 `DELETE` 전에 무엇을 해야 하는지 안다

체크하지 못한 항목이 있다면 해당 장을 다시 보고 오세요. 여기까지 왔다면 실무에서 마주치는 조회 요구의 대부분은 스스로 해결할 수 있습니다.
